/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM e:/builds/moz2_slave/rel-m-192-xr-w32-bld/build/docshell/base/nsCDefaultURIFixup.idl
 */

#ifndef __gen_nsCDefaultURIFixup_h__
#define __gen_nsCDefaultURIFixup_h__
/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
// {214C48A0-B57F-11d4-959C-0020183BF181}
#define NS_DEFAULTURIFIXUP_CID \
{ 0x214c48a0, 0xb57f, 0x11d4, { 0x95, 0x9c, 0x0, 0x20, 0x18, 0x3b, 0xf1, 0x81 } }
#define NS_URIFIXUP_CONTRACTID \
"@mozilla.org/docshell/urifixup;1"

#endif /* __gen_nsCDefaultURIFixup_h__ */
